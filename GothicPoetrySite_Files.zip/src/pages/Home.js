import React from "react";
import { motion } from "framer-motion";

const poems = [
  { id: 1, title: "Тёмная ночь", excerpt: "В ночи, где тени таят слова..." },
  { id: 2, title: "Лунный свет", excerpt: "Луна взошла и осветила путь..." },
];

function Home() {
  return (
    <div>
      <h1>Добро пожаловать в Gothic Poetry Site</h1>
      <p>Здесь ваш друг сможет публиковать стихи и рассказы в готическом стиле.</p>
      <h2>Последние произведения</h2>
      <div>
        {poems.map((poem) => (
          <motion.div
            key={poem.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: poem.id * 0.2 }}
            style={{
              backgroundColor: "#2b004d",
              marginBottom: "15px",
              padding: "15px",
              borderRadius: "6px",
              boxShadow: "0 0 10px #bb88ff77"
            }}
          >
            <h3>{poem.title}</h3>
            <p>{poem.excerpt}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default Home;