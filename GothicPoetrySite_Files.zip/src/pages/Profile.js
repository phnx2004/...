import React from "react";
import { auth } from "../firebase/firebaseConfig";
import { signOut } from "firebase/auth";
import { useNavigate } from "react-router-dom";

function Profile() {
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut(auth);
    navigate("/");
  };

  return (
    <div>
      <h2>Профиль</h2>
      <p>Добро пожаловать! Вы вошли в систему.</p>
      <button
        onClick={handleLogout}
        style={{ padding: "10px", backgroundColor: "#660099", color: "white", border: "none", cursor: "pointer" }}
      >
        Выйти
      </button>
    </div>
  );
}

export default Profile;